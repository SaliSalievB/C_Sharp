﻿Console.WriteLine("Enter Driven Kilometers");
double DrivenKilometers = Console.ReadLine();
Console.WriteLine("Enter Consumed fuel in liters");
double ConsumedFuel = int.Parse(Console.ReadLine());
double CarMiles = DrivenKilometers / ConsumedFuel;

Console.WriteLine($"{CarMiles}");


