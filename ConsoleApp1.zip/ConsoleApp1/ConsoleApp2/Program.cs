﻿string usernameE= "Sali";
int passwordE = 225511;
string sWordE = "Banana";

Console.WriteLine("Type Username");
string usernameU = Console.ReadLine();
Console.WriteLine("Type Password");
int passwordU = int.Parse(Console.ReadLine());
Console.WriteLine("Type Secret Word");
string sWordU = Console.ReadLine();

if (usernameE == usernameU)
{

    if (passwordE == passwordE)
    {
        if (sWordE == sWordU)
        {
            Console.WriteLine($"Welcome{usernameE}");
        }
    }
}
if (usernameU == "Dragon")
        {
            Console.WriteLine("Secret Level unlocked");
        }
else
{
    Console.WriteLine("Try again");
}