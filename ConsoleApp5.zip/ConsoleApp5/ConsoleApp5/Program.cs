﻿using System;
using System.Collections.Generic;
using System.Linq;

/*
class one
{
    static void Main()
    {
        Stack<int> itemWeights = new Stack<int>();

        Console.WriteLine("Enter the weight capacity of each shelf:");
        int shelfCapacity = int.Parse(Console.ReadLine());

        Console.WriteLine("Enter the weights of the items, separated by space:");
        string input = Console.ReadLine();
        string[] weightStrings = input.Split(' ');

        foreach (string weightString in weightStrings)
        {
            int weight = int.Parse(weightString);
            if (weight == 0)
            {
                break;
            }
            itemWeights.Push(weight);
        }

        int totalWeight = itemWeights.Sum();
        int shelvesNeeded = (totalWeight + shelfCapacity - 1) / shelfCapacity;

        Console.WriteLine("Total weight: " + totalWeight);
        Console.WriteLine("Shelf capacity: " + shelfCapacity);
        Console.WriteLine("Shelves needed: " + shelvesNeeded);
    }
}
*/
class Program
{
    static void Main()
    {
        Stack<string> tasks = new Stack<string>(Console.ReadLine().Split(", "));

        while (tasks.Count > 0)
        {
            string[] command = Console.ReadLine().Split(' ').ToArray();

            switch (command[0])
            {
                case "Complete":
                    if (tasks.Count == 0)
                    {
                        Console.WriteLine("No tasks left!");
                    }
                    else
                    {
                        tasks.Pop();
                    }
                    break;

                case "Add":
                    string taskToAdd = command[1];
                    if (tasks.Contains(taskToAdd))
                    {
                        Console.WriteLine($"{taskToAdd} is already contained!");
                    }
                    else
                    {
                        tasks.Push(taskToAdd);
                    }
                    break;

                case "Show":
                    Console.WriteLine(string.Join(", ", tasks));
                    break;

                default:
                    Console.WriteLine("Invalid command!");
                    break;
            }
        }

        Console.WriteLine("All tasks completed!");
    }
}
