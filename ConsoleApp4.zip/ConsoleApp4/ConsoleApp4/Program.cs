﻿using System;
using System.Collections.Generic;
using System.Runtime.Intrinsics.X86;
using static System.Net.Mime.MediaTypeNames;
using System.Collections.Generic;
using System.Linq;

/*
public class One
{
    public static void Main(string[] args)
    {
        List<int> Numbers = new List<int>();

        Console.WriteLine("Enter numbers to add to the list. Enter 'done' to finish.");
        while (true)
        {
            string input = Console.ReadLine();
            if (input.ToLower() == "done")
            {
                break;
            }
            else
            {
                int number = int.Parse(input);
                Numbers.Add(number);
            }
        }

        // Iterate list element using foreach loop  
        foreach (var Number in Numbers)
        {
            if(Number %2==0)
            Console.WriteLine(Number);
        }
    }
}
*/
/*
public class Two
{
    public static void Main(string[] args)
    {
        List<int> Numbers = new List<int>();

        Console.WriteLine("Enter numbers to add to the list. Enter 'done' to finish.");
        while (true)
        {
            string input = Console.ReadLine();
            if (input.ToLower() == "done")
            {
                break;
            }
            else
            {
                int number = int.Parse(input);
                Numbers.Add(number);
            }
        }

        // Find the maximum value in the list
        int max = Numbers.Max();
        Console.WriteLine($"The maximum value in the list is {max}.");
    }
}
*/
/*
class Three
{
    static void Main(string[] args)
    {
        // Read input from the console
        Console.Write("Enter a sentence: ");
        string input = Console.ReadLine();

        // Split the input into words
        string[] words = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        // Create a dictionary to store the word counts
        Dictionary<string, int> counts = new Dictionary<string, int>();

        // Count the occurrences of each word
        foreach (string word in words)
        {
            if (counts.ContainsKey(word))
            {
                counts[word]++;
            }
            else
            {
                counts[word] = 1;
            }
        }

        // Print the word counts
        foreach (KeyValuePair<string, int> entry in counts)
        {
            Console.WriteLine("{0}: {1}", entry.Key, entry.Value);
        }
    }
}
*/
/*
class Four
{
    static void Main(string[] args)
    {
        var list = new List<Tuple<string, int>>();
        string input;

        do
        {
            Console.Write("Enter a name and a score (separated by a space), or 'done' to finish: ");
            input = Console.ReadLine();

            if (input.ToLower() != "done")
            {
                string[] values = input.Split(' ');
                if (values.Length == 2 && int.TryParse(values[1], out int score))
                {
                    var tuple = Tuple.Create(values[0], score);
                    list.Add(tuple);
                }
                else
                {
                    Console.WriteLine("Invalid input, please try again.");
                }
            }
        } while (input.ToLower() != "done");

        double average = list.Average(tuple => tuple.Item2);
        Console.WriteLine("Average = " + average);
    }
}
*/
/*
class five
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter a list of integers separated by spaces:");
        string input = Console.ReadLine();
        List<int> numbers = input.Split().Select(int.Parse).ToList();

        numbers.RemoveAll(n => n < 0);

        if (numbers.Count > 0)
        {
            numbers.Reverse();
            Console.WriteLine(string.Join(" ", numbers));
        }
        else
        {
            Console.WriteLine("empty");
        }
    }
}

*/
/*
class six
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter a list of double numbers separated by spaces:");
        string input = Console.ReadLine();
        string[] tokens = input.Split(' ');
        List<double> numbers = new List<double>();

        foreach (string token in tokens)
        {
            double number;
            if (double.TryParse(token, out number))
            {
                numbers.Add(number);
            }
        }

        numbers.Sort();

        if (numbers.Count == 0)
        {
            Console.WriteLine("empty");
        }
        else
        {
            Console.Write(numbers[0]);
            for (int i = 1; i < numbers.Count; i++)
            {
                Console.Write(" <= " + numbers[i]);
            }
            Console.WriteLine();
        }
    }
}
*/
/*
class seven
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter a list of integers in the range [0...1000]:");
        List<int> numbers = Console.ReadLine()
            .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToList();

        // Sort the list in ascending order
        numbers.Sort();

        // Group the numbers by their value and count the occurrences
        var numberCounts = numbers.GroupBy(n => n)
                                  .ToDictionary(g => g.Key, g => g.Count());

        // Display the results
        foreach (var kvp in numberCounts)
        {
            Console.WriteLine($"{kvp.Key} -> {kvp.Value}");
        }
    }
}
*/
/*
class eight
{
    static void Main(string[] args)
    {
        Dictionary<string, int> dict = new Dictionary<string, int>()
        {
            {"apple", 5},
            {"banana", 12},
            {"cherry", 8},
            {"orange", 15}
        };

        List<string> keys = new List<string>();

        foreach (KeyValuePair<string, int> pair in dict)
        {
            if (pair.Value >= 10)
            {
                keys.Add(pair.Key);
            }
        }

        Console.WriteLine($"[{string.Join(", ", keys)}]");
    }
}
*/
/*
 
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter a sentence: ");
        string sentence = Console.ReadLine();
        Dictionary<char, int> frequency = new Dictionary<char, int>();

        foreach (char c in sentence)
        {
            if (!char.IsLetter(c)) continue;
            char lc = char.ToLower(c);
            if (frequency.ContainsKey(lc))
            {
                frequency[lc]++;
            }
            else
            {
                frequency[lc] = 1;
            }
        }

        foreach (KeyValuePair<char, int> pair in frequency)
        {
            Console.WriteLine($"{pair.Key}: {pair.Value}");
        }
    }
}
*/