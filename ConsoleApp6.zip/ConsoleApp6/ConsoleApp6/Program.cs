﻿using System;
/*
public class MyList<T>
{
    private T[] items;
    private int count;
    private const int defaultCapacity = 4;

    public MyList()
    {
        items = new T[defaultCapacity];
    }

    public MyList(int capacity)
    {
        if (capacity < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(capacity), "Capacity must be a non-negative number.");
        }
        items = new T[capacity];
    }

    public int Count
    {
        get { return count; }
    }

    public void Add(T item)
    {
        if (count == items.Length)
        {
            Array.Resize(ref items, items.Length * 2);
        }
        items[count++] = item;
    }

    public bool Remove(T item)
    {
        int index = IndexOf(item);
        if (index < 0)
        {
            return false;
        }
        RemoveAt(index);
        return true;
    }

    public void RemoveAt(int index)
    {
        if (index < 0 || index >= count)
        {
            throw new IndexOutOfRangeException(nameof(index));
        }
        count--;
        for (int i = index; i < count; i++)
        {
            items[i] = items[i + 1];
        }
        items[count] = default(T);
    }

    public T GetItem(int index)
    {
        if (index < 0 || index >= count)
        {
            throw new IndexOutOfRangeException(nameof(index));
        }
        return items[index];
    }

    public int IndexOf(T item)
    {
        for (int i = 0; i < count; i++)
        {
            if (Equals(item, items[i]))
            {
                return i;
            }
        }
        return -1;
    }

    public IEnumerator<T> GetEnumerator()
    {
        for (int i = 0; i < count; i++)
        {
            yield return items[i];
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        MyList<int> myList = new MyList<int>();
        myList.Add(1);
        myList.Add(2);
        myList.Add(3);
        myList.Remove(2);
        Console.WriteLine(myList.Count); // 2
        Console.WriteLine(myList.GetItem(1)); // 3
    }
}*/

interface IVehicle
{
    string Color { get; set; }
    string Brand { get; set; }
    string Model { get; set; }
    int Year { get; set; }
    string FuelType { get; set; }

    void Start();
    void Stop();
}

class Vehicle : IVehicle
{
    public string Color { get; set; }
    public string Brand { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }
    public string FuelType { get; set; }

    public bool VehicleStarted { get; set; }

    public void Start()
    {
        Console.WriteLine("Starting the vehicle...");
        VehicleStarted = true;
    }

    public void Stop()
    {
        Console.WriteLine("Stopping the vehicle...");
        VehicleStarted = false;
    }
}

class BasicCar : Vehicle
{
    public BasicCar(string color, string brand, string model, int year, string fuelType)
    {
        Color = color;
        Brand = brand;
        Model = model;
        Year = year;
        FuelType = fuelType;
    }
}

class LuxuryCar : Vehicle
{
    public bool Volume { get; set; }
    public bool AirConditioning { get; set; }

    public void TurnOnAirConditioning()
    {
        Console.WriteLine("Turning on the air conditioning...");
        AirConditioning = true;
    }

    public void TurnOffAirConditioning()
    {
        Console.WriteLine("Turning off the air conditioning...");
        AirConditioning = false;
    }
    public void TurnVolumeUP()
    {
        Console.WriteLine("BUMBUMBUM");
        Volume = true;
    }
    public void TurnVolumeDOWN()
    {
        Console.WriteLine("bumbumbum");
        Volume = false;
    }
}
class Program
{
    static void Main(string[] args)
    {
        BasicCar basicCar = new BasicCar("Red", "Honda", "Civic", 2020, "Gasoline");
        basicCar.Start();
        basicCar.Stop();

        LuxuryCar luxuryCar = new LuxuryCar();
        luxuryCar.Color = "Red";
        luxuryCar.Brand = "Ferrari";
        luxuryCar.Model = "812 GTS";
        luxuryCar.Year = 2022;
        luxuryCar.FuelType = "Diesel";
        luxuryCar.Start();
        luxuryCar.TurnOnAirConditioning();
        luxuryCar.Stop();
        luxuryCar.TurnOffAirConditioning();
        luxuryCar.TurnOnAirConditioning();
        luxuryCar.Stop();
        luxuryCar.Start();
        luxuryCar.TurnVolumeUP();
        luxuryCar.TurnVolumeDOWN();
        luxuryCar.Stop();
    }
}
