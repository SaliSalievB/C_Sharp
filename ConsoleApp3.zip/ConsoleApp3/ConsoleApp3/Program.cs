﻿using System;


/*
namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Put the value in Fahrenheit");
            double F = double.Parse(Console.ReadLine());
            double C = (F - 32) / 1.8000;
            Console.WriteLine(C);
        }
    }
}
*/
/*
namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            int power;
            double baseNum, result;
            Console.Write("Enter base number: ");
            baseNum = double.Parse(Console.ReadLine());
            Console.Write("Enter power: ");
            power = int.Parse(Console.ReadLine());
            result = Math.Pow(baseNum, power);
            Console.WriteLine("{0} raised to the power of {1} is {2}", baseNum, power, result);
        }
    }
}
*/
/*
namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a value: ");
            string input = Console.ReadLine();
            Console.WriteLine("Enter another value: ");
            string input1 = Console.ReadLine();

            // Try to parse the input as an int
            if (int.TryParse(input, out int intValue))
            {
                object intObj = intValue;
                Console.WriteLine("Value entered: " + intObj);
                if (int.TryParse(input1, out int intValue1))
                {
                    object intObj1 = intValue1;
                    Console.WriteLine("Value entered: " + intObj1);
                    int max = GetMax(intValue, intValue1);
                    Console.WriteLine("The larger value is " + max);
                }
                else
                {
                    object strObj1 = input1;
                    Console.WriteLine("Value entered: " + strObj1);
                    Console.WriteLine("Can't compare different types");
                }
            }
            // Try to parse the input as a double
            else if (double.TryParse(input, out double doubleValue))
            {
                object doubleObj = doubleValue;
                Console.WriteLine("Value entered: " + doubleObj);
                if (double.TryParse(input1, out double doubleValue1))
                {
                    object doubleObj1 = doubleValue1;
                    Console.WriteLine("Value entered: " + doubleObj1);
                    double max = GetMax(doubleValue, doubleValue1);
                    Console.WriteLine("The larger value is " + max);
                }
                else
                {
                    object strObj1 = input1;
                    Console.WriteLine("Value entered: " + strObj1);
                    Console.WriteLine("Can't compare different types");
                }
            }
            // Try to parse the input as a char
            else if (char.TryParse(input, out char charValue))
            {
                object charObj = charValue;
                Console.WriteLine("Value entered: " + charObj);
                if (char.TryParse(input1, out char charValue1))
                {
                    object charObj1 = charValue1;
                    Console.WriteLine("Value entered: " + charObj1);
                    char max = GetMax(charValue, charValue1);
                    Console.WriteLine("The larger value is " + max);
                }
                else
                {
                    object strObj1 = input1;
                    Console.WriteLine("Value entered: " + strObj1);
                    Console.WriteLine("Can't compare different types");
                }
            }
            // Store the input as a string if it can't be parsed as a number or char
            else
            {
                object strObj = input;
                Console.WriteLine("Value entered: " + strObj);
                if (double.TryParse(input1, out double doubleValue1))
                {
                    object doubleObj1 = doubleValue1;
                    Console.WriteLine("Value entered: " + doubleObj1);
                    Console.WriteLine("Can't compare different types");
                }
                else if (int.TryParse(input1, out int intValue1))
                {
                    object intObj1 = intValue1;
                    Console.WriteLine("Value entered: " + intObj1);
                    Console.WriteLine("Can't compare different types");
                }
                else if (char.TryParse(input1, out char charValue1))
                {
                    object charObj1= charValue1;


                    Console.WriteLine("Value entered: " + charObj1);
                    Console.WriteLine("Can't compare different types");
                }
                else
                {
                    object strObj1 = input1;
                    Console.WriteLine("Value entered: " + strObj1);
                    Console.WriteLine("Can't compare different types");
                }
            }

           
        Console.ReadLine();
        }

        // Define a method to get the maximum of two integers
        static int GetMax(int num1, int num2)
        {
            if (num1 > num2)
            {
                return num1;
            }
            else
            {
                return num2;
            }
        }

        // Define a method to get the maximum of two doubles
        static double GetMax(double num1, double num2)
        {
            if (num1 > num2)
            {
                return num1;
            }
            else
            {
                return num2;
            }
        }

        // Define a method to get the maximum of two chars
        static char GetMax(char char1, char char2)
        {
            if (char1 > char2)
            {
                return char1;
            }
            else
            {
                return char2;
            }
        }
    }
}
*/
/*
namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of elements to store in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];

            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("element - {0}: ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }

            Console.Write("Elements in the array: ");
            for (int i = 0; i < n; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }
    }
}
*/
/*
namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of elements to store in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];

            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("element - {0}: ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Elements in the array:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(arr[i]);
            }
            Console.WriteLine();
            Console.WriteLine("Elements in the reversed array:");
            Array.Reverse(arr);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}
*/
/*
namespace Task6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of elements to store in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];

            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("element - {0}: ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }
            int sum = arr.Sum();
            Console.WriteLine(sum);
        }
    }
}

*/

/*
namespace Task7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of elements to store in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];

            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("element - {0}: ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }
            int[] copy = new int[n];
            arr.CopyTo(copy, 0);

            Console.WriteLine("Elements in the copied array:");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(copy[i]);
            }
        }
    }
}
*/
/*
namespace Task8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of elements to store in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];

            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("element - {0}: ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }

            int count = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        count++;
                        break;
                    }
                }
            }

            Console.WriteLine("Total number of duplicate elements in the array: " + count);
        }
    }
}
*/
/*
namespace Task9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of elements to store in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];

            Console.WriteLine("Enter the elements:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("element - {0}: ", i);
                arr[i] = int.Parse(Console.ReadLine());
            }

            Console.Write("The unique elements in the array are: ");
            for (int i = 0; i < n; i++)
            {
                bool isUnique = true;
                for (int j = 0; j < n; j++)
                {
                    if (i != j && arr[i] == arr[j])
                    {
                        isUnique = false;
                        break;
                    }
                }
                if (isUnique)
                {
                    Console.Write(arr[i] + " ");
                }
            }
        }
    }
}
*/
/*
namespace Task10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first array:");
            int[] arr1 = ReadArray();
            Console.WriteLine("Enter the second array:");
            int[] arr2 = ReadArray();

            if (AreArraysIdentical(arr1, arr2))
            {
                Console.WriteLine("Arrays are identical. Sum: {0}", GetArraySum(arr1));
            }
            else
            {
                Console.WriteLine("Arrays are not identical. Found difference at {0} index", GetFirstDifferentIndex(arr1, arr2));
            }
        }

        static int[] ReadArray()
        {
            string[] input = Console.ReadLine().Split();
            int[] arr = new int[input.Length];

            for (int i = 0; i < input.Length; i++)
            {
                arr[i] = int.Parse(input[i]);
            }

            return arr;
        }

        static bool AreArraysIdentical(int[] arr1, int[] arr2)
        {
            if (arr1.Length != arr2.Length)
            {
                return false;
            }

            for (int i = 0; i < arr1.Length; i++)
            {
                if (arr1[i] != arr2[i])
                {
                    return false;
                }
            }

            return true;
        }

        static int GetArraySum(int[] arr)
        {
            int sum = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }

            return sum;
        }

        static int GetFirstDifferentIndex(int[] arr1, int[] arr2)
        {
            int minLength = Math.Min(arr1.Length, arr2.Length);

            for (int i = 0; i < minLength; i++)
            {
                if (arr1[i] != arr2[i])
                {
                    return i;
                }
            }

            return minLength;
        }
    }
}
*/