﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Ingredient
{
    public string Name { get; set; }
    public int Calories { get; set; }
    public int Quantity { get; set; }

    public Ingredient(string name, int calories, int quantity)
    {
        Name = name;
        Calories = calories;
        Quantity = quantity;
    }

    public override string ToString()
    {
        return $"Ingredient: {Name}\nQuantity: {Quantity}\nCalories: {Calories}";
    }
}
