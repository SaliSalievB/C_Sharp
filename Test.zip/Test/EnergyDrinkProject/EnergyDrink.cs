﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

using System.Collections.Generic;
using System.Linq;

public class EnergyDrink
{
    public string Name { get; set; }
    public int Capacity { get; set; }
    public int MaxCalories { get; set; }
    private List<Ingredient> ingredients;

    public EnergyDrink(string name, int capacity, int maxCalories)
    {
        Name = name;
        Capacity = capacity;
        MaxCalories = maxCalories;
        ingredients = new List<Ingredient>();
    }

    public bool Add(Ingredient ingredient)
    {
        bool nameExists = ingredients.Any(i => i.Name == ingredient.Name);
        int totalCalories = GetTotalCalories();
        int newTotalCalories = totalCalories + ingredient.Calories;
        bool enoughCapacity = ingredients.Count < Capacity && newTotalCalories <= MaxCalories;

        if (!nameExists && enoughCapacity)
        {
            ingredients.Add(ingredient);
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool Remove(string name)
    {
        Ingredient ingredientToRemove = FindIngredient(name);

        if (ingredientToRemove != null)
        {
            ingredients.Remove(ingredientToRemove);
            return true;
        }
        else
        {
            return false;
        }
    }

    public Ingredient FindIngredient(string name)
    {
        return ingredients.FirstOrDefault(i => i.Name == name);
    }

    public Ingredient GetMostCaloricIngredient()
    {
        return ingredients.OrderByDescending(i => i.Calories).FirstOrDefault();
    }

    public int CurrentCalorieCount
    {
        get { return GetTotalCalories(); }
    }

    private int GetTotalCalories()
    {
        return ingredients.Sum(i => i.Calories);
    }

    public string Report()
    {
        string ingredientList = string.Join("\n", ingredients.Select(i => i.ToString()));
        return $"EnergyDrink: {Name} - Current Calorie Count: {CurrentCalorieCount}\n{ingredientList}";
    }
}

namespace MyConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create instances of your classes and call their methods here
            Console.WriteLine("Hello, world!");
        }
    }
}

