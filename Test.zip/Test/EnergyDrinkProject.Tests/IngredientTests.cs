﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class IngredientTests
{
    [TestMethod]
    public void TestToString()
    {
        // Arrange
        Ingredient ingredient = new Ingredient("Sugar", 50, 2);

        // Act
        string result = ingredient.ToString();

        // Assert
        Assert.AreEqual("Ingredient: Sugar\nQuantity: 2\nCalories: 50", result);
    }
}