﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class EnergyDrinkTests
{
    [TestMethod]
    public void TestAdd()
    {
        // Arrange
        EnergyDrink energyDrink = new EnergyDrink("Red Bull", 5, 100);
        Ingredient ingredient1 = new Ingredient("Sugar", 50, 2);
        Ingredient ingredient2 = new Ingredient("Caffeine", 0, 1);

        // Act
        bool result1 = energyDrink.Add(ingredient1); // Should add successfully
        bool result2 = energyDrink.Add(ingredient2); // Should not add (not enough calories)

        // Assert
        Assert.IsTrue(result1);
        Assert.IsFalse(result2);
    }

    [TestMethod]
    public void TestRemove()
    {
        // Arrange
        EnergyDrink energyDrink = new EnergyDrink("Red Bull", 5, 100);
        Ingredient ingredient1 = new Ingredient("Sugar", 50, 2);
        Ingredient ingredient2 = new Ingredient("Caffeine", 0, 1);
        energyDrink.Add(ingredient1);
        energyDrink.Add(ingredient2);

        // Act
        bool result1 = energyDrink.Remove("Sugar"); // Should remove successfully
        bool result2 = energyDrink.Remove("Water"); // Should not remove (ingredient not found)

        // Assert
        Assert.IsTrue(result1);
        Assert.IsFalse(result2);
    }

    [TestMethod]
    public void TestFindIngredient()
    {
        // Arrange
        EnergyDrink energyDrink = new EnergyDrink("Red Bull", 5, 100);
        Ingredient ingredient1 = new Ingredient("Sugar", 50, 2);
        Ingredient ingredient2 = new Ingredient("Caffeine", 0, 1);
        energyDrink.Add(ingredient1);
        energyDrink.Add(ingredient2);

        // Act
        Ingredient result1 = energyDrink.FindIngredient("Sugar"); // Should find successfully
        Ingredient result2 = energyDrink.FindIngredient("Water"); // Should not find (ingredient not found)

        // Assert
        Assert.AreEqual(ingredient1, result1);
        Assert.IsNull(result2);
    }

    [TestMethod]
    public void TestGetMostCaloricIngredient()
    {
        // Arrange
        EnergyDrink energyDrink = new EnergyDrink("Red Bull", 5, 100);
        Ingredient ingredient1 = new Ingredient("Sugar", 50, 2);
        Ingredient ingredient2 = new Ingredient("Caffeine", 0, 1);
        Ingredient ingredient3 = new Ingredient("Taurine", 40, 1);
        energyDrink.Add(ingredient1);
        energyDrink.Add(ingredient2);
        energyDrink.Add(ingredient3);

        // Act
        Ingredient result = energyDrink.GetMostCaloricIngredient();

        // Assert
        Assert.AreEqual(ingredient1, result);
    }

    [TestMethod]
    public void TestCurrentCalorieCount()
    {
        // Arrange
        EnergyDrink energyDrink = new EnergyDrink("Red Bull", 5, 100);
        Ingredient ingredient1 = new Ingredient("Sugar", 50, 2);
        Ingredient ingredient2 = new Ingredient("Caffeine", 0, 1);
        energyDrink.Add(ingredient1);
        energyDrink.Add(ingredient2);
        // Act
        int result = energyDrink.CurrentCalorieCount;

        // Assert
        Assert.AreEqual(2, result);
    }

    [TestMethod]
    public void TestReport()
    {
        // Arrange
        EnergyDrink energyDrink = new EnergyDrink("Red Bull", 5, 100);
        Ingredient ingredient1 = new Ingredient("Sugar", 50, 2);
        Ingredient ingredient2 = new Ingredient("Caffeine", 0, 1);
        energyDrink.Add(ingredient1);
        energyDrink.Add(ingredient2);

        // Act
        string result = energyDrink.Report();

        // Assert
        Assert.AreEqual("EnergyDrink: Red Bull - Current Calorie Count: 2\nSugar\nCaffeine\n", result);
    }
}