﻿using System;
using System.Linq;
using System.Collections.Generic;
/*
 //#1
namespace HolidayPlanner
{
    class Program
    {
        static void Main(string[] args)
        {
            double budget = double.Parse(Console.ReadLine());
            string season = Console.ReadLine();

            string destination = "";
            double amountSpent = 0;

            if (budget <= 1000)
            {
                destination = "Somewhere in Bulgaria";
                if (season == "summer")
                {
                    amountSpent = budget * 0.4;
                }
                else
                {
                    amountSpent = budget * 0.6;
                }
            }
            else if (budget <= 2000)
            {
                destination = "Somewhere in the Balkans";
                if (season == "summer")
                {
                    amountSpent = budget * 0.5;
                }
                else
                {
                    amountSpent = budget * 0.7;
                }
            }
            else
            {
                destination = "Somewhere in Europe";
                amountSpent = budget * 0.8;
            }

            if (destination == "Somewhere in Europe")
            {
                Console.WriteLine("Luxury Resort");
            }
            else if (season == "summer")
            {
                Console.WriteLine("Beach");
            }
            else
            {
                Console.WriteLine("Ski Trip");
            }
            Console.WriteLine("{0:F2}", amountSpent);
        }
    }
}
*/

/*
//#2namespace WorldCup2022



namespace WorldCup2022
{

    namespace WorldCup2022
    {
        class Program
        {
            static void Main(string[] args)
            {
                double budget = double.Parse(Console.ReadLine());
                string category = Console.ReadLine();
                int peopleCount = int.Parse(Console.ReadLine());

                double transportationCost = 500;
                double remainingBudget = budget - transportationCost;

                double ticketCost = 0;
                if (category == "VIP")
                {
                    ticketCost = 799.99;
                }
                else if (category == "Normal")
                {
                    ticketCost = 499.99;
                }

                double totalCost = ticketCost * peopleCount;

                if (totalCost <= remainingBudget)
                {
                    Console.WriteLine($"Yes! You have {(remainingBudget - totalCost):F2} QAR left.");
                    Console.WriteLine($"Transportation cost: {transportationCost:F2}");
                }
                else
                {
                    Console.WriteLine($"Not enough money! You need {(totalCost - remainingBudget):F2} QAR.");
                }
            }
        }
    }
}
 */
    

/*
 //#3
namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int lostGames = int.Parse(Console.ReadLine());
            double headsetPrice = double.Parse(Console.ReadLine());
            double mousePrice = double.Parse(Console.ReadLine());
            double keyboardPrice = double.Parse(Console.ReadLine());
            double displayPrice = double.Parse(Console.ReadLine());

            int headsetDestroyed = lostGames / 2;
            int mouseDestroyed = lostGames / 3;
            int keyboardDestroyed = lostGames/6;
            int displayDestroyed = lostGames/ 6;

            double expenses = headsetDestroyed * headsetPrice + mouseDestroyed * mousePrice + keyboardDestroyed * keyboardPrice + displayDestroyed * displayPrice;
            Console.WriteLine("Expenses: {0:F2} lv.", expenses);
        }
    }
}
*/

/*
//#4using System;


namespace ArrayManipulator
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] array = Console.ReadLine().Split();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine().Split();
                switch (command[0])
                {
                    case "Reverse":
                        Array.Reverse(array);
                        break;
                    case "Distinct":
                        array = new HashSet<string>(array).ToArray();
                        break;
                    case "Replace":
                        int index = int.Parse(command[1]);
                        string value = command[2];
                        if (index >= 0 && index < array.Length)
                        {
                            array[index] = value;
                        }
                        break;
                }
            }

            Console.WriteLine(string.Join(", ", array));
        }
    }
}
*/



